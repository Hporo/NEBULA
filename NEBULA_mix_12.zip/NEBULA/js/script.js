//data
const WM = "https://commons.wikimedia.org/wiki/Special:FilePath/";
const planet = {
    sun: { name: "태양", type: "STAR", dist: "중심 (지구까지 1 AU)", desc: "태양계의 중심에 있는 별로, 태양계 전체 질량의 약 99.86%를 차지해요.", art: "art-sun", img: "The_Sun_by_the_Atmospheric_Imaging_Assembly_of_NASA%27s_Solar_Dynamics_Observatory_-_20100819.jpg" },
    mercury: { name: "수성", type: "TERRESTRIAL PLANET", dist: "0.39 AU", desc: "태양에 가장 가까운 가장 작은 행성이에요. 낮과 밤의 온도 차가 매우 커요.", art: "art-mercury", img: "Mercury_in_color_-_Prockter07-edit1.jpg" },
    venus: { name: "금성", type: "TERRESTRIAL PLANET", dist: "0.72 AU", desc: "두꺼운 이산화탄소 대기 덕분에 태양계에서 가장 뜨거운 행성이에요.", art: "art-venus", img: "Venus_2_Approach_Image.jpg" },
    earth: { name: "지구", type: "TERRESTRIAL PLANET", dist: "1.00 AU", desc: "액체 상태의 물과 생명이 존재하는 것으로 알려진 유일한 행성이에요.", art: "art-earth", img: "The_Earth_seen_from_Apollo_17.jpg" },
    moon: { name: "달", type: "NATURAL SATELLITE", dist: "지구에서 약 38만 km", desc: "지구의 유일한 자연 위성이에요.", art: "art-moon", img: "FullMoon2010.jpg" },
    mars: { name: "화성", type: "TERRESTRIAL PLANET", dist: "1.52 AU", desc: "산화철 때문에 붉게 보이는 행성으로, 태양계에서 가장 큰 화산이 있어요.", art: "art-mars", img: "OSIRIS_Mars_true_color.jpg" },
    jupiter: { name: "목성", type: "GAS GIANT", dist: "5.20 AU", desc: "태양계에서 가장 큰 행성이에요. 대적점이라 불리는 거대한 폭풍이 있어요.", art: "art-jupiter", img: "Jupiter_and_its_shrunken_Great_Red_Spot.jpg" },
    saturn: { name: "토성", type: "GAS GIANT", dist: "9.58 AU", desc: "얼음 조각으로 이루어진 뚜렷한 고리를 가진 가스 행성이에요.", art: "art-saturn", img: "Saturn_during_Equinox.jpg" },
    uranus: { name: "천왕성", type: "ICE GIANT", dist: "19.2 AU", desc: "자전축이 거의 옆으로 누워 있는, 푸른빛의 얼음 거대 행성이에요.", art: "art-uranus", img: "Uranus2.jpg" },
    neptune: { name: "해왕성", type: "ICE GIANT", dist: "30.1 AU", desc: "태양계의 가장 바깥쪽 행성으로, 매우 강한 바람이 부는 푸른 행성이에요.", art: "art-neptune", img: "Neptune_Full.jpg" }
};
// 행성 모음 분류 (메뉴의 내행성 / 외행성 / 위성과 동일)
const planetGroups = [
    { id: "inner", name: "내행성", keys: ["mercury", "venus", "earth"], cols: 3 },
    { id: "outer", name: "외행성", keys: ["mars", "jupiter", "saturn", "uranus", "neptune"], cols: 3 },
    { id: "star", name: "항성/위성", keys: ["sun", "moon"], cols: 2 }
];
const planetOrder = planetGroups.flatMap(g => g.keys);           // 팝업의 이전/다음 순서
const TYPE_KO = { "STAR": "항성", "TERRESTRIAL PLANET": "암석 행성", "GAS GIANT": "가스 거대 행성", "ICE GIANT": "얼음 거대 행성", "NATURAL SATELLITE": "자연 위성" };
// 지름(km), 지구 대비 지름 비율, 공전 주기, 자전 주기
const planetFacts = {
    sun:     { diam: "약 139만 km", ratio: 109.2, orbit: "은하 중심을 약 2.3억 년에 한 바퀴", spin: "약 25일 (적도)" },
    mercury: { diam: "4,879 km", ratio: .383, orbit: "88일", spin: "약 59일" },
    venus:   { diam: "12,104 km", ratio: .949, orbit: "225일", spin: "약 243일 (역방향)" },
    earth:   { diam: "12,742 km", ratio: 1, orbit: "365.25일", spin: "약 24시간" },
    moon:    { diam: "3,474 km", ratio: .273, orbit: "지구 둘레 약 27.3일", spin: "약 27.3일 (늘 같은 면이 지구를 향함)" },
    mars:    { diam: "6,779 km", ratio: .532, orbit: "687일", spin: "약 24.6시간" },
    jupiter: { diam: "139,820 km", ratio: 10.97, orbit: "약 11.9년", spin: "약 10시간" },
    saturn:  { diam: "116,460 km", ratio: 9.14, orbit: "약 29.5년", spin: "약 10.7시간" },
    uranus:  { diam: "50,724 km", ratio: 3.98, orbit: "약 84년", spin: "약 17.2시간 (역방향)" },
    neptune: { diam: "49,244 km", ratio: 3.86, orbit: "약 164.8년", spin: "약 16.1시간" }
};

//menu (food)
$("nav>ul>li").mouseover(function(){
    $(".sub,.menuBg").stop().slideDown();
})
$("nav>ul>li").mouseout(function(){
    $(".sub,.menuBg").stop().slideUp();
})
$("a[href='#']").click(function(e){ e.preventDefault(); });

//slide (food 방식으로 옆으로 밀기 + 이전/다음 버튼, 점, 마우스 올리면 정지)
let i = 0;
let slideTimer = null;
function goSlide(n){
    i = (n + 3) % 3;
    $(".slide ul").stop().animate({
        marginLeft: -1200 * i
    }, 1000);
    $(".slide-dots button").removeClass("on").eq(i).addClass("on");
}
function playSlide(){
    stopSlide();
    slideTimer = setInterval(function(){ goSlide(i + 1); }, 3000);
}
function stopSlide(){
    if(slideTimer){ clearInterval(slideTimer); slideTimer = null; }
}
$(".slide-prev").click(function(e){ e.preventDefault(); goSlide(i - 1); playSlide(); });
$(".slide-next").click(function(e){ e.preventDefault(); goSlide(i + 1); playSlide(); });
$(".slide-dots button").click(function(){ goSlide($(this).index()); playSlide(); });
$(".slide").hover(stopSlide, playSlide);
playSlide();

//tabmenu (food)
let t;
$(".tabmenu>li").click(function(e){
    e.preventDefault();
    $(".tabmenu>li").removeClass("on");
    $(this).addClass("on");
    t = $(this).index();

    $(".tabcon").hide();
    $(".tabcon").eq(t).show();
})
// 탭 안의 링크(행성 팝업·기능 열기)는 탭 전환을 건드리지 않도록
$(".tabcon a").click(function(e){ e.stopPropagation(); });

//popup (food 팝업 + 실제 사진 / 불러오지 못하면 그림으로 대체)
let popKey = null, popOpen = false;
function openPlanet(key){
    let p = planet[key];
    if(!p) return;
    popKey = key;
    const f = planetFacts[key];
    $("#pName").text(p.name);
    $("#pBadge").text(TYPE_KO[p.type] || p.type);
    $("#pDesc").text(p.desc);
    $("#pInfo").text("태양에서의 거리 · " + p.dist);
    if (f) {
        $("#pStats").html(`<li><span>지름</span><b>${f.diam}</b></li><li><span>공전 주기</span><b>${f.orbit}</b></li><li><span>자전 주기</span><b>${f.spin}</b></li>`);
        // 지구의 0.27배 ~ 109배까지 한 막대에 담기 위해 로그 눈금 사용
        const pct = Math.min(100, Math.max(6, (Math.log10(f.ratio) + .7) / 2.8 * 100));
        $("#pBar").css("width", pct + "%");
        $("#pRatio").text(f.ratio >= 10 ? "약 " + Math.round(f.ratio) + "배" : f.ratio === 1 ? "기준" : "약 " + f.ratio.toFixed(2).replace(/0+$/, "").replace(/\.$/, "") + "배");
        $(".pcompare, .pstats").show();
    } else { $(".pcompare, .pstats").hide(); }
    const img = document.getElementById("pImg");
    const art = document.getElementById("pArt");
    art.className = "planet-art " + p.art;
    img.hidden = true; art.hidden = false;
    img.onload = function(){ if(popKey === key){ img.hidden = false; art.hidden = true; } };
    img.onerror = function(){ if(popKey === key){ img.hidden = true; art.hidden = false; } };
    img.alt = p.name + " 사진";
    img.src = WM + p.img + "?width=900";
    popOpen = true;
    $("#popup").stop().fadeIn(200);
    document.querySelectorAll(".pcol-card").forEach(c => c.classList.toggle("viewed", c.dataset.pkey === key));
}
// 팝업 안에서 이전/다음 행성으로 넘기기 (끝에서 처음으로 이어짐)
function stepPlanet(dir){
    const i = planetOrder.indexOf(popKey);
    if (i < 0) return;
    openPlanet(planetOrder[(i + dir + planetOrder.length) % planetOrder.length]);
}
function closePlanet(){ popOpen = false; $("#popup").stop().fadeOut(200); }
$("[data-planet]").click(function(e){
    e.preventDefault();
    e.stopPropagation();
    openPlanet($(this).data("planet"));
})
$("#pClose").click(function(e){ e.preventDefault(); closePlanet(); });
$("#pPrev").click(function(e){ e.preventDefault(); stepPlanet(-1); });
$("#pNext").click(function(e){ e.preventDefault(); stepPlanet(1); });
$("#popup").click(function(e){ if(e.target === this) closePlanet(); });

//=====================================================================
// ▼ slide 파일에서 가져온 기능 (전체 화면 창으로 열림)
//=====================================================================
const $q = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function lockScroll(on){ document.body.style.overflow = on ? "hidden" : ""; }
function openOverlay(el){ el.classList.add("open"); el.setAttribute("aria-hidden", "false"); lockScroll(true); }
function closeOverlay(el){ el.classList.remove("open"); el.setAttribute("aria-hidden", "true"); lockScroll(false); }

// ---------- 별자리 연결 ----------
const constellationData = Object.fromEntries(constellationCatalog.map(c => [c.key, c]));
const constellationSets = Object.fromEntries(constellationCatalog.map(c => [c.key, {
    name: c.name, desc: c.desc, stars: c.stars.map(s => [s.ko, s.x, s.y, s.lp]), links: c.links,
    bright: c.bright, brightInfo: c.brightInfo
}]));
const constellationOverlay = $q("#constellationOverlay");
const constellationStage = $q(".constellation-stage");
const ovStars = $q("#ovStars");
const ovLines = $q("#ovLines");
const ovFx = $q("#ovFx");
const constellationProgress = $q("#constellationProgress");
const constellationName = $q("#constellationName");
const constellationDesc = $q("#constellationDesc");
const completeBanner = $q("#completeBanner");
const nextBtn = $q("#nextConstellation");
const hintBtn = $q("#hintStars");
const constellationChoices = $q("#constellationChoices");
const cstTabs = $q("#cstTabs");
let activeGroup = "zodiac";
const groupOf = (id) => constellationGroups.find(g => g.id === id);
// 분류 탭(황도 12궁 / 봄·여름·가을·겨울) 만들기
constellationGroups.forEach(g => {
    const b = document.createElement("button");
    b.className = "cst-tab"; b.dataset.group = g.id; b.type = "button"; b.setAttribute("role", "tab");
    b.textContent = g.label;
    b.addEventListener("click", () => {
        setGroup(g.id);
        selectConstellation(g.keys[0]);
    });
    cstTabs.appendChild(b);
});
// 선택한 분류의 별자리 버튼 만들기
function setGroup(id) {
    activeGroup = id;
    const g = groupOf(id);
    $$(".cst-tab").forEach(t => { const on = t.dataset.group === id; t.classList.toggle("active", on); t.setAttribute("aria-selected", String(on)); });
    $q("#cstGroupNote").textContent = g.note;
    constellationChoices.innerHTML = "";
    g.keys.forEach((k, n) => {
        const c = constellationData[k];
        const b = document.createElement("button");
        b.className = "constellation-choice"; b.dataset.constellation = k;
        b.innerHTML = `<i>${c.sym ? c.sym + "\uFE0E" : n + 1}</i><span>${c.name.replace("자리", "")}</span>`;
        b.title = c.name;
        b.addEventListener("click", () => selectConstellation(k));
        constellationChoices.appendChild(b);
    });
    markChoices();
}
function markChoices() {
    $$(".constellation-choice").forEach(x => {
        x.classList.toggle("active", x.dataset.constellation === activeConstellation);
        x.classList.toggle("done", doneConstellations.has(x.dataset.constellation));
    });
    $q("#cstDexCount").textContent = `${doneConstellations.size} / ${constellationCatalog.length}`;
}
// 오른쪽 정보 패널 채우기
function fillInfo(c) {
    const role = c.zodiac
        ? `황도 12궁 ${c.zodiac}번째`
        : `${SEASON_KO[c.season]} 대표 별자리`;
    const rep = constellationGroups.filter(g => g.id !== "zodiac" && g.keys.includes(c.key)).map(g => g.label);
    const rows = [
        ["분류", role + (c.zodiac && rep.length ? ` · ${rep.join("·")} 대표` : ""), 2],
        ["학명", `${c.latin} (${c.abbr})`, c.zodiac ? 1 : 2],
        ...(c.zodiac ? [["생일 기간", c.period, 1]] : []),
        ["잘 보이는 때", c.best, 2]
    ];
    $q("#cstTag").textContent = c.tag + " · " + c.en.split(" · ")[1];
    $q("#cstLatin").textContent = c.en;
    $q("#cstChips").innerHTML = rows.map(([k, v, w]) => `<div class="w${w}"><dt>${k}</dt><dd>${v}</dd></div>`).join("");
    $q("#cstStory").textContent = c.story;
    $q("#cstFind").textContent = c.find;
    $q("#cstFact").textContent = c.fact;
    $q("#cstBrightName").textContent = `${c.stars[c.bright].ko} (${c.mag}등)`;
    $q("#cstBright").textContent = c.brightInfo;
    $q("#cstInfo").scrollTop = 0;
}
let activeConstellation = "aries";
let anchorStar = null;          // 지금 선택해 둔 별
let drawnLinks = [];            // 이미 그린 선 ("작은번호-큰번호")
let hintOn = false;
let isComplete = false;
const doneConstellations = new Set();
const linkKey = (a, b) => (a < b ? `${a}-${b}` : `${b}-${a}`);
const svgLine = (a, b, cls) => {
    const l = document.createElementNS("http://www.w3.org/2000/svg", "line");
    l.setAttribute("x1", a[1]); l.setAttribute("y1", a[2]); l.setAttribute("x2", b[1]); l.setAttribute("y2", b[2]);
    if (cls) l.setAttribute("class", cls);
    return l;
};
function setStatus(text) { constellationDesc.textContent = text; }
// 가장 밝은 별을 누르면 그 별의 설명도 함께 보여 줌
function starTip(index) {
    const d = constellationSets[activeConstellation];
    return index === d.bright ? ` ★ ${d.stars[index][0]}: ${d.brightInfo}` : "";
}
function baseDesc() { return constellationSets[activeConstellation].desc; }

function buildOvConstellation() {
    const data = constellationSets[activeConstellation];
    constellationName.textContent = data.name;
    anchorStar = null; drawnLinks = []; isComplete = false;
    constellationStage.classList.remove("complete", "flash");
    completeBanner.hidden = true; nextBtn.hidden = true; ovFx.innerHTML = "";
    ovStars.innerHTML = "";
    data.stars.forEach((star, index) => {
        const btn = document.createElement("button");
        btn.className = "constellation-star" + (index === data.bright ? " bright" : "");
        btn.style.left = star[1] + "%"; btn.style.top = star[2] + "%"; btn.style.setProperty("--i", index);
        if (star[3]) btn.dataset.lp = star[3];
        btn.setAttribute("aria-label", star[0] + " 선택");
        btn.innerHTML = `<span>${star[0]}</span>`;
        btn.addEventListener("click", () => onStarClick(index, btn));
        ovStars.appendChild(btn);
    });
    setStatus(`${baseDesc()} 별을 눌러 시작해 보세요.`);
    renderOvLines();
}
function renderOvLines() {
    const data = constellationSets[activeConstellation];
    ovLines.innerHTML = "";
    if (hintOn && !isComplete) {
        data.links.forEach(([a, b]) => { if (!drawnLinks.includes(linkKey(a, b))) ovLines.appendChild(svgLine(data.stars[a], data.stars[b], "guide")); });
    }
    drawnLinks.forEach(k => { const [a, b] = k.split("-").map(Number); ovLines.appendChild(svgLine(data.stars[a], data.stars[b])); });
    const linked = new Set(drawnLinks.flatMap(k => k.split("-").map(Number)));
    [...ovStars.children].forEach((el, n) => {
        el.classList.toggle("selected", n === anchorStar);
        el.classList.toggle("linked", linked.has(n));
    });
    constellationProgress.textContent = `${drawnLinks.length} / ${data.links.length} 선 연결`;
}
function onStarClick(index, btn) {
    if (isComplete) return;
    const data = constellationSets[activeConstellation];
    if (anchorStar === null) { anchorStar = index; setStatus(`${data.stars[index][0]}에서 이어질 별을 눌러 보세요.${starTip(index)}`); renderOvLines(); return; }
    if (anchorStar === index) { anchorStar = null; setStatus(baseDesc()); renderOvLines(); return; }
    const key = linkKey(anchorStar, index);
    const valid = data.links.some(([a, b]) => linkKey(a, b) === key);
    if (valid && !drawnLinks.includes(key)) {
        drawnLinks.push(key); anchorStar = index;
        renderOvLines();
        if (drawnLinks.length === data.links.length) { celebrate(); return; }
        setStatus(`${data.stars[index][0]}에서 계속 이어 보세요. 더 이을 곳이 없으면 다른 별을 눌러 새로 시작해요.${starTip(index)}`);
    } else if (valid) {
        anchorStar = index; setStatus("이미 연결된 선이에요. 다른 별로 이어 보세요."); renderOvLines();
    } else {
        btn.classList.remove("shake"); void btn.offsetWidth; btn.classList.add("shake");
        anchorStar = index; setStatus("두 별 사이에는 선이 없어요. 이 별에서 다시 시작해요. (힌트 보기를 눌러 보세요)"); renderOvLines();
    }
}
// 완성 연출: 빛 번쩍임 + 선/별 반짝임 + 불꽃 입자 + 완성 문구
function celebrate() {
    const data = constellationSets[activeConstellation];
    isComplete = true; anchorStar = null; hintOn = false; hintBtn.setAttribute("aria-pressed", "false"); hintBtn.classList.remove("on");
    renderOvLines();
    doneConstellations.add(activeConstellation);
    markChoices();
    constellationStage.classList.add("complete", "flash");
    setStatus(`${data.desc} — 별자리를 완성했어요! 오른쪽 도감에서 신화와 관측법을 읽어 보세요.`);
    completeBanner.textContent = `✦ ${data.name} 도감 등록! ✦ (${doneConstellations.size} / ${constellationCatalog.length})`;
    completeBanner.hidden = false;
    nextBtn.hidden = false; nextBtn.textContent = groupOf(activeGroup).keys.every(k => doneConstellations.has(k)) ? "이 분류 처음부터 →" : "다음 별자리 →";
    ovFx.innerHTML = '<span class="fx-ring"></span><span class="fx-ring fx-ring2"></span>';
    data.stars.forEach(star => {
        for (let k = 0; k < 7; k++) {
            const sp = document.createElement("i"); sp.className = "spark";
            const ang = Math.random() * 6.283, dist = 30 + Math.random() * 70;
            sp.style.left = star[1] + "%"; sp.style.top = star[2] + "%";
            sp.style.setProperty("--dx", Math.cos(ang) * dist + "px"); sp.style.setProperty("--dy", Math.sin(ang) * dist + "px");
            sp.style.animationDelay = (Math.random() * .35) + "s";
            ovFx.appendChild(sp);
        }
    });
    setTimeout(() => { constellationStage.classList.remove("flash"); ovFx.innerHTML = ""; }, 2200);
}
function selectConstellation(key) {
    activeConstellation = key;
    if (!groupOf(activeGroup).keys.includes(key)) setGroup(constellationGroups.find(g => g.keys.includes(key)).id);
    markChoices();
    fillInfo(constellationData[key]);
    buildOvConstellation();
}
function openConstellationPopup() { openOverlay(constellationOverlay); selectConstellation(activeConstellation); }
setGroup("zodiac");
function closeConstellationPopup() { closeOverlay(constellationOverlay); }
$$("[data-close-constellations]").forEach(b => b.addEventListener("click", closeConstellationPopup));
constellationOverlay.addEventListener("click", e => { if (e.target === constellationOverlay) closeConstellationPopup(); });
$q("#resetStars").addEventListener("click", () => buildOvConstellation());
$q("#undoStar").addEventListener("click", () => {
    if (isComplete) return;
    drawnLinks.pop(); anchorStar = null; setStatus(baseDesc()); renderOvLines();
});
hintBtn.addEventListener("click", () => {
    if (isComplete) return;
    hintOn = !hintOn; hintBtn.setAttribute("aria-pressed", String(hintOn)); hintBtn.classList.toggle("on", hintOn); renderOvLines();
});
nextBtn.addEventListener("click", () => {
    const keys = groupOf(activeGroup).keys;
    if (keys.every(k => doneConstellations.has(k))) keys.forEach(k => doneConstellations.delete(k));
    const idx = keys.indexOf(activeConstellation);
    let nextKey = keys[(idx + 1) % keys.length];
    for (let n = 1; n <= keys.length; n++) { const k = keys[(idx + n) % keys.length]; if (!doneConstellations.has(k)) { nextKey = k; break; } }
    selectConstellation(nextKey);
});

// ---------- 메인 우주 탐험: 행성 모음 ----------
const universeOverlay = $q("#universeOverlay");
const pcolGroups = $q("#pcolGroups");
const pcolTabs = $q("#pcolTabs");
function openUniverse() { openOverlay(universeOverlay); makeUniverseStars(); }
function closeUniverse() { closeOverlay(universeOverlay); }
$$("[data-close-universe]").forEach(b => b.addEventListener("click", closeUniverse));
function makeUniverseStars() {
    const holder = $q("#universeStars"); if (holder.childElementCount) return;
    for (let n = 0; n < 115; n++) {
        const s = document.createElement("i"); s.className = "universe-star";
        s.style.left = (Math.random() * 100) + "%"; s.style.top = (Math.random() * 100) + "%";
        s.style.animationDelay = (Math.random() * 3) + "s"; s.style.opacity = (.25 + Math.random() * .75).toFixed(2);
        holder.appendChild(s);
    }
}
// 행성 카드: 원 크기는 실제 지름 비율(로그)을 줄여서 표현
const orbSize = (key) => Math.round(Math.min(112, Math.max(46, 70 + 22 * Math.log10(planetFacts[key].ratio))));
planetGroups.forEach((g, gi) => {
    const sec = document.createElement("section");
    sec.className = "pcol-group"; sec.dataset.group = g.id; sec.style.setProperty("--cols", g.cols); sec.style.setProperty("--gi", gi);
    sec.innerHTML = `<h3>${g.name}<small>${g.keys.length}</small></h3><div class="pcol-grid"></div>`;
    const grid = sec.querySelector(".pcol-grid");
    g.keys.forEach((key, ki) => {
        const p = planet[key], size = orbSize(key);
        const card = document.createElement("button");
        card.type = "button"; card.className = "pcol-card"; card.dataset.pkey = key;
        card.style.setProperty("--d", (gi * 4 + ki) * 60 + "ms");
        card.setAttribute("aria-label", `${p.name} 자세히 보기`);
        card.innerHTML = `<span class="pcol-orb"><span class="planet-art ${p.art}" style="width:${size}px;height:${size}px"></span></span>
            <strong>${p.name}</strong><em>${TYPE_KO[p.type]}</em><small>${p.dist}</small>`;
        card.addEventListener("click", () => openPlanet(key));
        grid.appendChild(card);
    });
    pcolGroups.appendChild(sec);
});
// 분류 탭 (전체 / 내행성 / 외행성 / 위성)
[{ id: "all", name: "전체" }, ...planetGroups].forEach((g, i) => {
    const b = document.createElement("button");
    b.type = "button"; b.dataset.tab = g.id; b.textContent = g.name; b.setAttribute("role", "tab");
    b.className = i === 0 ? "on" : "";
    b.addEventListener("click", () => {
        $$("#pcolTabs button").forEach(x => x.classList.toggle("on", x === b));
        pcolGroups.classList.toggle("solo", g.id !== "all");
        $$(".pcol-group").forEach(sec => { sec.hidden = g.id !== "all" && sec.dataset.group !== g.id; });
    });
    pcolTabs.appendChild(b);
});

// ---------- 천체 사진 갤러리 ----------
const galleryOverlay = $q("#galleryOverlay");
function updateGalleryCount() {
    $$('[data-count="gallery"]').forEach(el => { el.textContent = $$(".real-photo").length; });
}
// 불러오지 못한 사진 카드는 숨기고 개수를 다시 계산
$$(".real-photo[data-optional] img").forEach(img => {
    const drop = () => { img.closest(".real-photo").remove(); updateGalleryCount(); };
    if (img.complete && img.naturalWidth === 0 && img.currentSrc) drop();
    else img.addEventListener("error", drop, { once: true });
});
updateGalleryCount();
$$('[data-count="constellations"]').forEach(el => { el.textContent = constellationCatalog.length; });

// ---------- 마우스 반응형 성운 (캔버스) ----------
// 개선점: ① 노이즈 구름 질감(8가지 모양) ② 마우스 속도 기반 휘젓기 ③ 완전 재그리기 + 블룸 + 그레인(잔상 얼룩 제거)
//        ④ 어두운 먼지 레이어 + 색 보간 ⑤ 회절 스파이크 별 + 유성 ⑥ 충격파 + 구름 퍼짐 클릭 ⑦ 터치/저장/자동 색 변화/탭 숨김 정지
const nebulaOverlay = $q("#nebulaOverlay");
const nebula = (() => {
    const stage = $q("#nebulaStage");
    const canvas = $q("#nebulaCanvas");
    const hint = $q("#nebulaHint");
    const ctx = canvas.getContext("2d");
    const palettes = {
        aurora: [[167,139,250],[94,234,212],[244,114,182],[96,165,250]],
        violet: [[167,139,250],[139,92,246],[192,132,252],[99,102,241]],
        teal: [[94,234,212],[45,212,191],[56,189,248],[134,239,172]]
    };
    const paletteOrder = ["aurora", "violet", "teal"];
    const STAR_COLORS = [[255,255,255],[190,212,255],[255,216,176]];
    const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const MS = 160;                         // 구름 질감 한 장의 해상도
    let w = 0, h = 0, dpr = 1, raf = null, last = 0, running = false;
    let quality = 0, frameEma = .016, mode = "attract", targetKey = "aurora", autoColor = false, autoTimer = 0, t = 0, shootTimer = 3;
    const pointer = { x: 0, y: 0, sx: 0, sy: 0, vx: 0, vy: 0, speed: 0, active: false };
    let blobs = [], lanes = [], stars = [], puffs = [], rings = [], shooters = [];
    let masks = null, laneMasks = null, grainPattern = null, bgGrad = null, vignette = null;
    const bloomA = document.createElement("canvas"), bloomB = document.createElement("canvas");
    const bctxA = bloomA.getContext("2d"), bctxB = bloomB.getContext("2d");
    const rnd = (a, b) => a + Math.random() * (b - a);
    // 종류별 크기·농도·납작한 정도 (같은 구름만 보이지 않도록 서로 다르게)
    const LOOK = { billow: { r: [170, 290], a: [.2, .3], asp: [.8, 1.25] }, wisp: { r: [220, 360], a: [.26, .38], asp: [.7, 1.3] },
        streak: { r: [250, 400], a: [.26, .36], asp: [.45, .8] }, shell: { r: [160, 280], a: [.2, .3], asp: [.9, 1.15] },
        spiral: { r: [190, 310], a: [.22, .34], asp: [.8, 1.1] }, core: { r: [120, 200], a: [.24, .34], asp: [.8, 1.2] },
        cirrus: { r: [280, 420], a: [.16, .24], asp: [.6, 1.0] }, filament: { r: [240, 380], a: [.3, .42], asp: [.8, 1.2] } };

    // ----- ① 노이즈로 구름 질감 만들기 -----
    function makeNoise(seed) {
        const perm = new Uint8Array(512), val = new Float32Array(256);
        let s = seed >>> 0;
        const r = () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296;
        for (let i = 0; i < 256; i++) { perm[i] = i; val[i] = r(); }
        for (let i = 255; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const tmp = perm[i]; perm[i] = perm[j]; perm[j] = tmp; }
        for (let i = 0; i < 256; i++) perm[i + 256] = perm[i];
        const sm = q => q * q * (3 - 2 * q);
        return (x, y) => {
            const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi, X = xi & 255, Y = yi & 255;
            const a = val[perm[perm[X] + Y]], b = val[perm[perm[X + 1] + Y]], c = val[perm[perm[X] + Y + 1]], d = val[perm[perm[X + 1] + Y + 1]];
            const u = sm(xf), v = sm(yf);
            return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
        };
    }
    const smooth = (a, b, x) => { const q = Math.min(1, Math.max(0, (x - a) / (b - a))); return q * q * (3 - 2 * q); };
    // 흰색 + 알파만 가진 구름 마스크 (나중에 색을 입힘). 종류마다 모양이 확연히 다르다.
    const TYPES = ["billow", "wisp", "streak", "shell", "spiral", "core", "cirrus", "filament"];
    function makeMask(seed, type) {
        const c = document.createElement("canvas"); c.width = c.height = MS;
        const g = c.getContext("2d"), img = g.createImageData(MS, MS), n = makeNoise(seed);
        const fbm = (x, y, oct = 4) => { let a = .5, f = 1, s = 0, m = 0; for (let o = 0; o < oct; o++) { s += a * n(x * f, y * f); m += a; a *= .5; f *= 2.03; } return s / m; };
        for (let y = 0; y < MS; y++) for (let x = 0; x < MS; x++) {
            const nx = (x / MS - .5) * 2, ny = (y / MS - .5) * 2, rr = Math.hypot(nx, ny);
            const edge = Math.max(0, 1 - rr), fall = edge * edge * (3 - 2 * edge);
            const u = x / MS, v0 = y / MS;
            let m = 0;
            if (type === "billow") {            // 뭉게뭉게 솜덩이
                const px = u * 3.2, py = v0 * 3.2, q = fbm(px, py);
                m = smooth(.28, .78, fbm(px + 2.2 * q, py + 2.2 * (1 - q))) * fall;
            } else if (type === "wisp") {       // 가느다란 띠가 얽힌 안개
                const px = u * 3.2, py = v0 * 3.2, q = fbm(px, py), v = fbm(px + 2.2 * q, py + 2.2 * (1 - q));
                m = smooth(.55, .92, 1 - Math.abs(v * 2 - 1)) * fall;
            } else if (type === "streak") {     // 한 방향으로 길게 늘어진 줄무늬
                const px = u * 1.3, py = v0 * 7, q = fbm(px, py, 3), v = fbm(px + 1.6 * q, py + .6 * q, 4);
                m = smooth(.36, .78, v) * Math.pow(fall, .8);
            } else if (type === "shell") {      // 터져 나간 듯한 고리/거품
                const px = u * 4, py = v0 * 4, v = fbm(px, py);
                const ring = Math.exp(-Math.pow((rr - (.52 + .12 * (v - .5))) / .14, 2));
                m = ring * smooth(.18, .62, v + .12) * (rr < 1 ? 1 : 0) * smooth(1, .85, rr);
            } else if (type === "spiral") {     // 소용돌이 팔
                const ang = Math.atan2(ny, nx) + rr * 3.6, sx = Math.cos(ang) * rr * 2.4 + 5, sy = Math.sin(ang) * rr * 2.4 + 5;
                const q = fbm(sx, sy, 3), v = fbm(sx + 1.4 * q, sy + 1.4 * q);
                m = smooth(.34, .72, v) * fall * (.4 + .6 * smooth(0, .5, rr + .15));
            } else if (type === "core") {       // 짙은 중심 + 가닥 같은 가장자리
                const px = u * 3.6, py = v0 * 3.6, v = fbm(px + 3, py + 3);
                const core = Math.pow(edge, 2.4), tendril = smooth(.42, .78, v) * fall;
                m = Math.min(1, core * .75 + tendril * .55);
            } else if (type === "cirrus") {     // 크고 부드러운 얼룩
                const px = u * 1.7, py = v0 * 1.7;
                m = smooth(.32, .72, fbm(px + 8, py + 8, 3)) * Math.pow(fall, .7);
            } else {                            // filament: 가늘고 선명한 실타래
                const px = u * 4.6, py = v0 * 4.6, q = fbm(px, py), v = fbm(px + 3.4 * q, py + 3.4 * (1 - q));
                m = smooth(.74, .96, 1 - Math.abs(v * 2 - 1)) * fall * .85;
            }
            const i = (y * MS + x) * 4;
            img.data[i] = img.data[i + 1] = img.data[i + 2] = 255; img.data[i + 3] = Math.round(Math.min(1, m) * 255);
        }
        g.putImageData(img, 0, 0);
        // 날카로운 경계를 부드럽게: 축소했다가 다시 키워서 가볍게 흐리기 (가는 실타래·줄무늬는 선명하게 유지)
        {
            const k = type === "streak" ? .5 : type === "filament" ? .22 : .3, sm = document.createElement("canvas"); sm.width = sm.height = Math.round(MS * k);
            const sg = sm.getContext("2d"); sg.imageSmoothingQuality = "high"; sg.drawImage(c, 0, 0, sm.width, sm.height);
            g.clearRect(0, 0, MS, MS); g.imageSmoothingQuality = "high"; g.globalAlpha = .82; g.drawImage(sm, 0, 0, MS, MS); g.globalAlpha = 1;
        }
        return c;
    }
    function tint(sprite, mask, col) {
        const g = sprite.getContext("2d");
        g.globalCompositeOperation = "source-over"; g.clearRect(0, 0, MS, MS); g.drawImage(mask, 0, 0);
        g.globalCompositeOperation = "source-in"; g.fillStyle = `rgb(${col[0] | 0},${col[1] | 0},${col[2] | 0})`; g.fillRect(0, 0, MS, MS);
    }
    function newSprite() { const c = document.createElement("canvas"); c.width = c.height = MS; return c; }
    function ensureAssets() {
        if (masks) return;
        masks = TYPES.map((tp, k) => makeMask(101 + k * 37, tp));
        laneMasks = [0, 1, 2].map(k => makeMask(907 + k * 53, "wisp"));
        const g = document.createElement("canvas"); g.width = g.height = 128;
        const gc = g.getContext("2d"), img = gc.createImageData(128, 128);
        for (let i = 0; i < img.data.length; i += 4) { img.data[i] = img.data[i + 1] = img.data[i + 2] = 255; img.data[i + 3] = Math.random() * 255; }
        gc.putImageData(img, 0, 0);
        grainPattern = ctx.createPattern(g, "repeat");
    }

    function resize() {
        const r = stage.getBoundingClientRect();
        w = Math.max(1, Math.floor(r.width)); h = Math.max(1, Math.floor(r.height));
        dpr = quality ? 1 : Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = w * dpr; canvas.height = h * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        bloomA.width = Math.max(2, Math.ceil(w / 4)); bloomA.height = Math.max(2, Math.ceil(h / 4));
        bloomB.width = Math.max(2, Math.ceil(w / 16)); bloomB.height = Math.max(2, Math.ceil(h / 16));
        bgGrad = ctx.createLinearGradient(0, 0, 0, h);
        bgGrad.addColorStop(0, "#07041a"); bgGrad.addColorStop(.5, "#0d0832"); bgGrad.addColorStop(1, "#060316");
        vignette = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .35, w / 2, h / 2, Math.hypot(w, h) * .62);
        vignette.addColorStop(0, "rgba(3,1,12,0)"); vignette.addColorStop(1, "rgba(3,1,12,.55)");
        if (!pointer.active) { pointer.x = pointer.sx = w / 2; pointer.y = pointer.sy = h / 2; }
        build();
    }
    function build() {
        ensureAssets();
        const small = w < 600, pal = palettes[targetKey];
        const order = TYPES.map((_, i) => i).sort(() => Math.random() - .5);
        blobs = Array.from({ length: small ? 9 : 14 }, (_, k) => {
            const ti = order[k % TYPES.length], look = LOOK[TYPES[ti]], sc = small ? .72 : 1;
            const hx = Math.random() * w, hy = Math.random() * h, col = pal[(k + (k >= TYPES.length ? 2 : 0)) % pal.length].slice();
            const mask = masks[ti], sprite = newSprite();
            tint(sprite, mask, col);
            const asp = rnd(look.asp[0], look.asp[1]);
            return { hx, hy, x: hx, y: hy, vx: 0, vy: 0, r: rnd(look.r[0], look.r[1]) * sc, sx: asp > 1 ? asp : 1, sy: asp > 1 ? 1 : asp,
                a: rnd(look.a[0], look.a[1]), ph: rnd(0, 6.28), sp: rnd(.2, .6), rot: rnd(0, 6.28), rs: rnd(.03, .09) * (Math.random() < .5 ? -1 : 1),
                col, shown: col.map(Math.round), mask, sprite, k: k + (k >= TYPES.length ? 2 : 0) };
        });
        // ④ 어두운 먼지 띠: 밝은 구름 위에 짙은 남색을 덮어 명암(입체감)을 만든다
        lanes = Array.from({ length: small ? 4 : 7 }, (_, k) => {
            const hx = Math.random() * w, hy = Math.random() * h, sprite = newSprite();
            tint(sprite, laneMasks[k % laneMasks.length], [5, 3, 20]);
            return { hx, hy, x: hx, y: hy, vx: 0, vy: 0, r: rnd(150, 300) * (small ? .7 : 1), a: rnd(.45, .7),
                ph: rnd(0, 6.28), sp: rnd(.1, .3), rot: rnd(0, 6.28), rs: rnd(-.04, .04), sprite };
        });
        stars = Array.from({ length: small ? 90 : 190 }, () => {
            const big = Math.random() < .12;
            return { x: Math.random() * w, y: Math.random() * h, z: rnd(.3, 1.2), s: big ? rnd(1.3, 2.1) : rnd(.5, 1.4),
                ph: rnd(0, 6.28), big, c: STAR_COLORS[Math.random() < .6 ? 0 : (Math.random() < .5 ? 1 : 2)] };
        });
        puffs = []; rings = []; shooters = [];
    }
    function setColor(key) {
        if (key === "auto") { autoColor = true; autoTimer = 0; return; }
        autoColor = false; targetKey = key;
    }
    // ⑥ 클릭: 충격파 링 + 부풀어 퍼지는 구름 + 주변 구름·먼지 밀어내기
    function burst(x, y) {
        rings.push({ x, y, r: 8, life: 1 }, { x, y, r: 4, life: 1, slow: true });
        for (let k = 0; k < 4; k++) {
            const src = blobs[Math.floor(Math.random() * blobs.length)];
            puffs.push({ x: x + rnd(-14, 14), y: y + rnd(-14, 14), r: 16, grow: rnd(170, 320), life: 1, rot: rnd(0, 6.28), rs: rnd(-.9, .9), src });
        }
        for (const b of blobs) {
            const dx = b.x - x, dy = b.y - y, d = Math.hypot(dx, dy) || 1;
            if (d < 560) { const f = (1 - d / 560) * 230; b.vx += dx / d * f; b.vy += dy / d * f; }
        }
    }
    // 구름 덩어리 한 개의 움직임: 제자리 주변을 떠다니고, 마우스에 끌리거나 밀리고, 마우스 속도로 휘저어진다 (②)
    function stepBlob(b, dt, drift, pull, stir) {
        const tx = b.hx + Math.cos(t * b.sp + b.ph) * 40 * drift, ty = b.hy + Math.sin(t * b.sp * .8 + b.ph) * 30 * drift;
        let fx = (tx - b.x) * 1.2, fy = (ty - b.y) * 1.2;
        if (pointer.active) {
            const dx = pointer.sx - b.x, dy = pointer.sy - b.y, d = Math.hypot(dx, dy) || 1, range = 460;
            if (d < range) {
                const fall = 1 - d / range, hold = mode === "attract" ? smooth(30, 230, d) : 1;   // 끌어당길 때 커서 근처에서는 힘이 줄어 한곳에 뭉치지 않음
                const k = fall * (mode === "attract" ? 600 : -720) * pull * hold;
                fx += dx / d * k; fy += dy / d * k;
                const sp = Math.min(1, pointer.speed / 700);
                fx += pointer.vx * fall * .45 * stir; fy += pointer.vy * fall * .45 * stir;           // 마우스가 지나가는 방향으로 밀림
                const cross = Math.sign(dx * pointer.vy - dy * pointer.vx) || 0;                        // 휘젓는 방향으로 소용돌이
                fx += (-dy / d) * cross * fall * sp * 300 * stir; fy += (dx / d) * cross * fall * sp * 300 * stir;
            }
        }
        b.vx = (b.vx + fx * dt) * .92; b.vy = (b.vy + fy * dt) * .92;
        b.x += b.vx * dt * 6; b.y += b.vy * dt * 6;
        b.rot += b.rs * dt * (reduceMotion ? 0 : 1);
    }

    // 구름끼리 겹침 정도를 계산해 서로 살짝 밀어내고, 많이 겹친 구름은 흐려지게 함
    function separate(list, dt) {
        for (const b of list) b.crowd = 0;
        for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) {
            const a = list[i], c = list[j], dx = c.x - a.x, dy = c.y - a.y, d = Math.hypot(dx, dy) || 1;
            const reach = (a.r + c.r) * .5;
            if (d < reach) {
                const o = 1 - d / reach;
                a.crowd += o; c.crowd += o;
                const f = o * 160 * dt;
                a.vx -= dx / d * f; a.vy -= dy / d * f; c.vx += dx / d * f; c.vy += dy / d * f;
            }
        }
    }

    function frame(now) {
        if (!running) return;
        const rawDt = (now - last) / 1000 || .016, dt = Math.min(.05, rawDt); last = now; t += dt;
        // 느린 기기 자동 대응: 프레임이 계속 느리면 화질(해상도·입자·번짐)을 한 단계 낮춤
        frameEma += (Math.min(.2, rawDt) - frameEma) * .05;
        if (!quality && t > 2.5 && frameEma > .04) { quality = 1; resize(); }
        pointer.sx += (pointer.x - pointer.sx) * Math.min(1, dt * 7);
        pointer.sy += (pointer.y - pointer.sy) * Math.min(1, dt * 7);
        const decay = Math.pow(.03, dt);                       // 마우스가 멈추면 속도가 빠르게 0으로
        pointer.vx *= decay; pointer.vy *= decay; pointer.speed = Math.hypot(pointer.vx, pointer.vy);
        const drift = reduceMotion ? 0 : 1;

        // ⑦ 자동 색 변화 + ④ 색 보간(부드럽게 섞이도록)
        if (autoColor) { autoTimer += dt; if (autoTimer > 6) { autoTimer = 0; targetKey = paletteOrder[(paletteOrder.indexOf(targetKey) + 1) % paletteOrder.length]; } }
        const pal = palettes[targetKey], rate = Math.min(1, dt * (autoColor ? .9 : 2.4));
        for (const b of blobs) {
            const tc = pal[b.k % pal.length];
            for (let i = 0; i < 3; i++) b.col[i] += (tc[i] - b.col[i]) * rate;
            const r0 = Math.round(b.col[0]), r1 = Math.round(b.col[1]), r2 = Math.round(b.col[2]);
            if (r0 !== b.shown[0] || r1 !== b.shown[1] || r2 !== b.shown[2]) { b.shown = [r0, r1, r2]; tint(b.sprite, b.mask, b.shown); }
        }

        // ③ 매 프레임 완전히 다시 그림 → 반투명 덮어쓰기 때문에 생기던 검은 잔상 얼룩/밴딩이 생기지 않음
        ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1;
        ctx.fillStyle = bgGrad; ctx.fillRect(0, 0, w, h);

        // 성운 본체: 중심 글로우 + 노이즈 구름 질감 (회전하며 흐름)
        separate(blobs, dt);
        // 'screen' 합성: 겹쳐도 색이 유지되며 천천히 밝아져서(덧셈처럼 한 번에 하얗게 타지 않음)
        ctx.globalCompositeOperation = "screen";
        for (let bi = 0; bi < blobs.length; bi++) {
            if (quality && bi >= 9) break;
            const b = blobs[bi];
            stepBlob(b, dt, drift, 1, 1);
            const near = pointer.active ? Math.max(0, 1 - Math.hypot(pointer.sx - b.x, pointer.sy - b.y) / 420) : 0;
            const crowd = 1 / (1 + b.crowd * 1.1);                       // 겹칠수록 농도를 낮춤
            const rad = b.r * (1 + near * .12), al = (b.a + near * .06) * crowd;
            const gl = ctx.createRadialGradient(b.x, b.y, 0, b.x, b.y, rad * 1.05);
            gl.addColorStop(0, `rgba(${b.shown[0]},${b.shown[1]},${b.shown[2]},${al * .32})`);
            gl.addColorStop(1, `rgba(${b.shown[0]},${b.shown[1]},${b.shown[2]},0)`);
            ctx.globalAlpha = 1; ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(b.x, b.y, rad * 1.05, 0, 6.283); ctx.fill();
            ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.rot); ctx.scale(b.sx, b.sy); ctx.globalAlpha = Math.min(1, al);
            ctx.drawImage(b.sprite, -rad, -rad, rad * 2, rad * 2); ctx.restore();
        }

        // 어두운 먼지 띠 (밝은 구름을 가려 명암을 만듦)
        ctx.globalCompositeOperation = "source-over";
        for (let li = 0; li < lanes.length; li++) {
            if (quality && li >= 3) break;
            const l = lanes[li];
            stepBlob(l, dt, drift, .35, .6);
            ctx.save(); ctx.translate(l.x, l.y); ctx.rotate(l.rot); ctx.globalAlpha = l.a;
            ctx.drawImage(l.sprite, -l.r, -l.r, l.r * 2, l.r * 2); ctx.restore();
        }
        ctx.globalAlpha = 1;

        // 커서 주변의 빛
        ctx.globalCompositeOperation = "lighter";
        if (pointer.active) {
            const c = palettes[targetKey][0], rr = 150 + Math.min(80, pointer.speed * .06);
            const g = ctx.createRadialGradient(pointer.sx, pointer.sy, 0, pointer.sx, pointer.sy, rr);
            g.addColorStop(0, `rgba(${c[0]},${c[1]},${c[2]},.12)`); g.addColorStop(1, `rgba(${c[0]},${c[1]},${c[2]},0)`);
            ctx.fillStyle = g; ctx.beginPath(); ctx.arc(pointer.sx, pointer.sy, rr, 0, 6.283); ctx.fill();
        }

        // ⑤ 별: 시차 이동 + 색온도 + 밝은 별은 십자 회절 스파이크
        const px = (pointer.sx - w / 2) / w, py = (pointer.sy - h / 2) / h;
        for (const s of stars) {
            const x = s.x - px * 30 * s.z, y = s.y - py * 30 * s.z;
            let a = .35 + .35 * Math.sin(t * 1.6 + s.ph);
            if (pointer.active) a += Math.max(0, 1 - Math.hypot(pointer.sx - x, pointer.sy - y) / 170) * .7;
            a = Math.min(1, Math.max(.05, a));
            ctx.fillStyle = `rgba(${s.c[0]},${s.c[1]},${s.c[2]},${a})`;
            ctx.beginPath(); ctx.arc(x, y, s.s * (.7 + s.z * .5), 0, 6.283); ctx.fill();
            if (s.big) {
                const L = s.s * (6 + 4 * Math.sin(t * 1.1 + s.ph)) * (.8 + a);
                ctx.strokeStyle = `rgba(${s.c[0]},${s.c[1]},${s.c[2]},${a * .55})`; ctx.lineWidth = .8;
                ctx.beginPath(); ctx.moveTo(x - L, y); ctx.lineTo(x + L, y); ctx.moveTo(x, y - L); ctx.lineTo(x, y + L); ctx.stroke();
            }
        }

        // ⑤ 유성
        if (!reduceMotion) {
            shootTimer -= dt;
            if (shootTimer <= 0) {
                shootTimer = rnd(4, 9);
                const sp = rnd(520, 820), ang = rnd(.35, .75);
                shooters.push({ x: rnd(.05, .7) * w, y: rnd(0, .35) * h, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, life: 1 });
            }
            for (let k = shooters.length - 1; k >= 0; k--) {
                const s = shooters[k];
                s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt * .85;
                if (s.life <= 0 || s.x > w + 80 || s.y > h + 80) { shooters.splice(k, 1); continue; }
                const tx = s.x - s.vx * .13, ty = s.y - s.vy * .13, al = Math.min(1, s.life * 1.6);
                const g = ctx.createLinearGradient(tx, ty, s.x, s.y);
                g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(1, `rgba(255,255,255,${.9 * al})`);
                ctx.strokeStyle = g; ctx.lineWidth = 1.6; ctx.lineCap = "round";
                ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(s.x, s.y); ctx.stroke();
            }
        }

        // ⑥ 클릭 효과: 구름이 부풀며 퍼짐 + 충격파 링
        for (let k = puffs.length - 1; k >= 0; k--) {
            const p = puffs[k];
            p.r += p.grow * dt; p.grow *= Math.pow(.25, dt); p.life -= dt * .7; p.rot += p.rs * dt;
            if (p.life <= 0) { puffs.splice(k, 1); continue; }
            ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.globalAlpha = Math.min(1, p.life * 1.1) * .55;
            ctx.drawImage(p.src.sprite, -p.r, -p.r, p.r * 2, p.r * 2); ctx.restore();
        }
        ctx.globalAlpha = 1;
        for (let k = rings.length - 1; k >= 0; k--) {
            const r = rings[k];
            r.r += (r.slow ? 240 : 420) * dt * r.life; r.life -= dt * (r.slow ? .9 : 1.5);
            if (r.life <= 0) { rings.splice(k, 1); continue; }
            const rc = palettes[targetKey][0];
            ctx.strokeStyle = `rgba(${rc[0]},${rc[1]},${rc[2]},${r.life * .7})`; ctx.lineWidth = 1 + r.life * 3;
            ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 6.283); ctx.stroke();
        }

        // ③ 블룸: 축소본을 겹쳐서 부드러운 빛 번짐을 만듦 (ctx.filter 없이 모든 브라우저에서 동작)
        bctxA.globalCompositeOperation = "copy"; bctxA.drawImage(canvas, 0, 0, bloomA.width, bloomA.height);
        bctxB.globalCompositeOperation = "copy"; bctxB.drawImage(bloomA, 0, 0, bloomB.width, bloomB.height);
        ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
        ctx.globalCompositeOperation = "lighter";
        ctx.globalAlpha = .38; ctx.drawImage(bloomA, 0, 0, w, h);
        if (!quality) { ctx.globalAlpha = .5; ctx.drawImage(bloomB, 0, 0, w, h); }

        // 비네팅 + 움직이는 그레인(색 띠 현상 완화)
        ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1;
        ctx.fillStyle = vignette; ctx.fillRect(0, 0, w, h);
        if (!quality) {
            ctx.save(); ctx.translate(Math.floor(Math.random() * 128), Math.floor(Math.random() * 128));
            ctx.globalCompositeOperation = "lighter"; ctx.globalAlpha = .035; ctx.fillStyle = grainPattern; ctx.fillRect(-128, -128, w + 256, h + 256);
            ctx.restore();
        }
        ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1;

        raf = requestAnimationFrame(frame);
    }

    function pos(e) {
        const r = canvas.getBoundingClientRect();
        return [e.clientX - r.left, e.clientY - r.top];
    }
    let lastEvT = 0;
    stage.addEventListener("pointermove", e => {
        if (e.target.closest(".nebula-controls")) return;
        const [x, y] = pos(e), now = e.timeStamp || performance.now();
        if (pointer.active && lastEvT) {
            const ds = Math.max(8, now - lastEvT) / 1000;
            pointer.vx = pointer.vx * .55 + ((x - pointer.x) / ds) * .45;
            pointer.vy = pointer.vy * .55 + ((y - pointer.y) / ds) * .45;
            pointer.speed = Math.hypot(pointer.vx, pointer.vy);
        } else {
            pointer.vx = pointer.vy = 0;
        }
        lastEvT = now; pointer.x = x; pointer.y = y; pointer.active = true; hint.classList.add("hidden");
    });
    stage.addEventListener("pointerleave", () => { pointer.active = false; lastEvT = 0; });
    stage.addEventListener("pointerdown", e => {
        if (e.target.closest(".nebula-controls")) return;
        [pointer.x, pointer.y] = pos(e); pointer.sx = pointer.x; pointer.sy = pointer.y; pointer.active = true; lastEvT = e.timeStamp || performance.now();
        hint.classList.add("hidden"); burst(pointer.x, pointer.y);
    });
    $$("[data-neb-mode]").forEach(b => b.addEventListener("click", () => {
        mode = b.dataset.nebMode;
        $$("[data-neb-mode]").forEach(x => x.classList.toggle("active", x === b));
    }));
    $$("[data-neb-color]").forEach(b => b.addEventListener("click", () => {
        setColor(b.dataset.nebColor);
        $$("[data-neb-color]").forEach(x => x.classList.toggle("active", x === b));
    }));

    // ⑦ 스크린샷 저장
    const toast = document.createElement("div"); toast.className = "nebula-toast"; stage.appendChild(toast);
    let toastTimer = null;
    function showToast(msg) { toast.textContent = msg; toast.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 1800); }
    $q("#nebSave").addEventListener("click", () => {
        canvas.toBlob(blob => {
            if (!blob) { showToast("저장에 실패했어요"); return; }
            const d = new Date(), p2 = n => String(n).padStart(2, "0");
            const a = document.createElement("a");
            a.href = URL.createObjectURL(blob);
            a.download = `nebula-${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}-${p2(d.getHours())}${p2(d.getMinutes())}${p2(d.getSeconds())}.png`;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(a.href), 1500);
            showToast("✦ 이미지로 저장했어요");
        }, "image/png");
    });

    // ⑦ 탭/창이 숨겨지면 애니메이션 정지, 돌아오면 이어서 재생
    document.addEventListener("visibilitychange", () => {
        if (!running) return;
        if (document.hidden) { if (raf) cancelAnimationFrame(raf); raf = null; }
        else if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); }
    });
    if ("ResizeObserver" in window) new ResizeObserver(() => { if (running) resize(); }).observe(stage);
    else window.addEventListener("resize", () => { if (running) resize(); });
    return {
        start() {
            if (running) return;
            running = true; hint.classList.remove("hidden"); t = 0; frameEma = .016;
            resize();
            last = performance.now(); if (!document.hidden) raf = requestAnimationFrame(frame);
        },
        stop() { running = false; if (raf) cancelAnimationFrame(raf); raf = null; }
    };
})();
function openNebula() { openOverlay(nebulaOverlay); nebula.start(); }
function closeNebula() { nebula.stop(); closeOverlay(nebulaOverlay); }
function openGallery() { openOverlay(galleryOverlay); }
function closeGallery() { closeOverlay(galleryOverlay); }

// ---------- 창 열기/닫기 연결 (메뉴·슬라이드·배너·탭에서 data-open 으로 호출) ----------
const openers = { constellation: openConstellationPopup, universe: openUniverse, gallery: openGallery, nebula: openNebula };
$$("[data-open]").forEach(el => el.addEventListener("click", e => {
    e.preventDefault(); e.stopPropagation();
    const fn = openers[el.dataset.open];
    if (fn) { $(".sub,.menuBg").stop().slideUp(150); fn(); }
}));
$$("[data-close-fx]").forEach(b => b.addEventListener("click", () => {
    if (nebulaOverlay.contains(b)) closeNebula(); else closeGallery();
}));
galleryOverlay.addEventListener("click", e => { if (e.target === galleryOverlay) closeGallery(); });
nebulaOverlay.addEventListener("click", e => { if (e.target === nebulaOverlay) closeNebula(); });

// ESC: 열려 있는 팝업을 모두 닫음
document.addEventListener("keydown", e => {
    if (e.key !== "Escape") return;
    if (popOpen) { closePlanet(); return; }
    if (constellationOverlay.classList.contains("open")) closeConstellationPopup();
    if (universeOverlay.classList.contains("open")) closeUniverse();
    if (galleryOverlay.classList.contains("open")) closeGallery();
    if (nebulaOverlay.classList.contains("open")) closeNebula();
});

// ---------- 마우스를 따라오는 배경 성운 빛 ----------
let pointerFrame = null;
document.addEventListener("pointermove", (event) => {
    if (event.pointerType === "touch" || pointerFrame !== null) return;
    pointerFrame = requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--mouse-x", `${event.clientX}px`);
        document.documentElement.style.setProperty("--mouse-y", `${event.clientY}px`);
        $$(".nebula-cloud").forEach((cloud, index) => {
            const factor = index === 0 ? 0.018 : -0.012;
            const dx = (event.clientX - window.innerWidth / 2) * factor;
            const dy = (event.clientY - window.innerHeight / 2) * factor;
            cloud.style.transform = `translate(${dx}px, ${dy}px)`;
        });
        pointerFrame = null;
    });
}, { passive: true });

//=====================================================================
// ▼ 탭: 오늘의 밤하늘 / 우주 퀴즈
//=====================================================================
// 탭 안의 버튼을 눌러도 탭 전환 핸들러가 다시 실행되지 않도록
$(".tabcon").click(function(e){ e.stopPropagation(); });

// ---------- 오늘의 밤하늘 ----------
(function skyToday() {
    const now = new Date();
    const DAY_KO = ["일", "월", "화", "수", "목", "금", "토"];
    $q("#skyDate").textContent = `${now.getMonth() + 1}월 ${now.getDate()}일 ${DAY_KO[now.getDay()]}요일`;

    // 달 위상: 2000-01-06 18:14 UTC 의 삭(새달)을 기준으로 평균 삭망월(29.53일)로 계산한 근삿값
    const SYN = 29.530588853;
    const age = (((now.getTime() - Date.UTC(2000, 0, 6, 18, 14)) / 86400000) % SYN + SYN) % SYN;
    const illum = Math.round((1 - Math.cos(2 * Math.PI * age / SYN)) / 2 * 100);
    const phases = [["🌑", "삭(새달)"], ["🌒", "초승달"], ["🌓", "상현달"], ["🌔", "차오르는 달"], ["🌕", "보름달"], ["🌖", "기우는 달"], ["🌗", "하현달"], ["🌘", "그믐달"]];
    const [icon, label] = phases[Math.floor(age / SYN * 8 + .5) % 8];
    $q("#moonIco").textContent = icon;
    $q("#moonText").textContent = `${label} · 월령 약 ${age.toFixed(1)}일 · 밝기 약 ${illum}%`;

    // 이번 달 잘 보이는 별자리: 각 별자리의 '잘 보이는 때'(예: 12월 · 밤 9시경) 달과 가까운 순서
    const month = now.getMonth() + 1;
    const gap = (c) => { const m = parseInt(c.best, 10); const d = Math.abs(m - month); return Math.min(d, 12 - d); };
    const picks = constellationCatalog.slice().sort((a, b) => gap(a) - gap(b)).slice(0, 3);
    const chips = $q("#skyChips");
    picks.forEach(c => {
        const b = document.createElement("button");
        b.type = "button"; b.title = `${c.name} · ${c.best}`;
        b.innerHTML = `<i>${c.sym ? c.sym + "︎" : "✦"}</i>${c.name}`;
        b.addEventListener("click", () => {
            $(".sub,.menuBg").stop().slideUp(150);
            openConstellationPopup(); selectConstellation(c.key);
        });
        chips.appendChild(b);
    });

    // 오늘의 우주 상식: 날짜로 골라서 하루 동안 같은 문장이 보임
    const facts = [
        "빛은 초당 약 30만 km를 이동해요.",
        "우주는 진공이라 소리가 전달되지 않아요.",
        "별빛은 아주 오래전 과거의 모습이에요.",
        "태양빛이 지구에 닿기까지 약 8분 20초가 걸려요.",
        "금성은 다른 행성들과 반대 방향으로 자전해요.",
        "목성의 대적점은 지구보다 큰 폭풍이에요.",
        "토성은 밀도가 물보다 낮아요.",
        "달은 해마다 약 3.8cm씩 지구에서 멀어져요."
    ];
    const dayNo = Math.floor((Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) - Date.UTC(now.getFullYear(), 0, 0)) / 86400000);
    $q("#skyFact").textContent = facts[dayNo % facts.length];
})();

// ---------- 우주 퀴즈 ----------
(function spaceQuiz() {
    const POOL = [
        { q: "태양계에서 가장 큰 행성은?", o: ["토성", "목성", "천왕성", "해왕성"], a: 1, e: "목성은 대적점이라는 거대한 폭풍이 있어요." },
        { q: "태양계에서 가장 뜨거운 행성은?", o: ["수성", "금성", "화성", "지구"], a: 1, e: "두꺼운 이산화탄소 대기가 열을 가둬요." },
        { q: "붉게 보이는 행성은?", o: ["화성", "목성", "해왕성", "금성"], a: 0, e: "표면의 산화철 때문에 붉게 보여요." },
        { q: "빛은 1초에 약 얼마를 갈까요?", o: ["3만 km", "30만 km", "300만 km", "3억 km"], a: 1, e: "초속 약 30만 km예요." },
        { q: "우주에서 소리가 안 들리는 이유는?", o: ["너무 추워서", "너무 어두워서", "진공이라서", "중력이 약해서"], a: 2, e: "소리를 전달할 공기가 없어요." },
        { q: "뚜렷한 고리로 유명한 행성은?", o: ["토성", "화성", "수성", "금성"], a: 0, e: "얼음과 암석 조각으로 이루어진 고리예요." },
        { q: "가장 큰 화산이 있는 행성은?", o: ["금성", "화성", "지구", "수성"], a: 1, e: "화성의 올림포스 화산이에요." },
        { q: "자전축이 옆으로 누운 행성은?", o: ["천왕성", "목성", "화성", "수성"], a: 0, e: "푸른빛의 얼음 거대 행성이에요." },
        { q: "태양 다음으로 가장 밝은 별은?", o: ["베가", "시리우스", "북극성", "알데바란"], a: 1, e: "밤하늘에서 가장 밝은 별이에요." },
        { q: "햇빛이 지구에 닿는 데 걸리는 시간은?", o: ["약 1초", "약 8분", "약 1시간", "약 하루"], a: 1, e: "약 8분 20초가 걸려요." },
        { q: "태양에서 가장 먼 행성은?", o: ["천왕성", "토성", "해왕성", "목성"], a: 2, e: "약 30 AU 거리의 푸른 행성이에요." },
        { q: "지구의 자연 위성은?", o: ["달", "포보스", "유로파", "타이탄"], a: 0, e: "지구의 유일한 자연 위성이에요." },
        { q: "태양은 태양계 질량의 약 몇 %?", o: ["약 50%", "약 75%", "약 90%", "약 99.9%"], a: 3, e: "나머지 모두를 합쳐도 약 0.14%예요." },
        { q: "여름철 대삼각형의 별이 아닌 것은?", o: ["베가", "데네브", "알타이르", "시리우스"], a: 3, e: "시리우스는 겨울철 별이에요." }
    ];
    const ROUND = 5, BEST_KEY = "nebulaQuizBest";
    const box = $q("#quizBox");
    const original = box.innerHTML;                 // 결과 화면에서 돌아올 때 쓰는 원래 구조
    let set = [], idx = 0, score = 0, answered = false;
    const readBest = () => { try { return parseInt(localStorage.getItem(BEST_KEY), 10) || 0; } catch (err) { return 0; } };
    const saveBest = (n) => { try { localStorage.setItem(BEST_KEY, String(n)); } catch (err) {} };

    function start() {
        box.classList.remove("result"); box.innerHTML = original;
        set = POOL.slice().sort(() => Math.random() - .5).slice(0, ROUND);
        idx = 0; score = 0; show();
        $q("#quizNext").addEventListener("click", next);
    }
    function show() {
        answered = false;
        const item = set[idx];
        // 보기 순서도 섞어 줌
        const opts = item.o.map((text, i) => ({ text, ok: i === item.a })).sort(() => Math.random() - .5);
        $q("#quizNo").textContent = `Q${idx + 1} / ${ROUND}`;
        $q("#quizScore").textContent = `점수 ${score}`;
        $q("#quizQ").textContent = item.q;
        $q("#quizExp").textContent = "보기를 눌러 정답을 맞혀 보세요.";
        $q("#quizNext").hidden = true;
        const holder = $q("#quizOpts"); holder.innerHTML = "";
        opts.forEach(o => {
            const b = document.createElement("button"); b.type = "button"; b.textContent = o.text;
            b.addEventListener("click", () => {
                if (answered) return; answered = true;
                if (o.ok) { score++; b.classList.add("right"); $q("#quizExp").textContent = "정답! " + item.e; }
                else { b.classList.add("wrong"); $q("#quizExp").textContent = "아쉬워요. " + item.e; }
                $q("#quizExp").title = $q("#quizExp").textContent;
                [...holder.children].forEach((x, k) => { x.disabled = true; if (opts[k].ok) x.classList.add("right"); });
                $q("#quizScore").textContent = `점수 ${score}`;
                const last = idx === ROUND - 1;
                $q("#quizNext").textContent = last ? "결과 ›" : "다음 ›"; $q("#quizNext").hidden = false;
            });
            holder.appendChild(b);
        });
    }
    function next() { if (!answered) return; if (idx < ROUND - 1) { idx++; show(); } else finish(); }
    function finish() {
        const best = Math.max(readBest(), score); saveBest(best);
        const msg = score === ROUND ? "완벽해요! 우주 박사님 🚀" : score >= 3 ? "잘했어요! 조금만 더 도전해 볼까요?" : "괜찮아요, 다시 도전하면 더 잘할 수 있어요!";
        box.classList.add("result");
        box.innerHTML = `<div class="quiz-result"><strong>${score} / ${ROUND} 정답</strong><p>${msg}</p><p>최고 기록 ${best} / ${ROUND}</p><button type="button" class="quiz-next" id="quizRetry">다시 도전 ›</button></div>`;
        $q("#quizRetry").addEventListener("click", start);
    }
    start();
})();
